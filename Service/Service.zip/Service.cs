﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace Quanto
{
    [RoutePrefix("TextilePOS")]
    public class CompaniesController : ApiController
    {
        [Route("ListOfPrinters")]
        [HttpGet]
        public  async Task<IHttpActionResult> ListOfPrinters()
        {
            List<Quanto.Printer.PrinterService.Printer> result = await Task<List<Quanto.Printer.PrinterService.Printer>>.Run(() => Quanto.Printer.PrinterService.Instance.ListOfPrinters());
            return this.Ok(result);
        }

        [Route("License")]
        [HttpGet]
        public async Task<IHttpActionResult> License()
        {
            Quanto.Printer.PrinterService.LocationInfo result = await Task<Quanto.Printer.PrinterService.LocationInfo>.Run(() => Quanto.Printer.PrinterService.Instance.GetLicense());
            return this.Ok(result);
        }
        

        [Route("Transfer2Tally")]
        [HttpPost]
        public async Task<IHttpActionResult> Transfer2Tally(Quanto.TallyVocher document)
        {
            var result = await Task<bool>.Run(() => Quanto.TallyServer.Instance.Transfer(document));
            return this.Ok(result);
        }

        [Route("PrintRAW")]
        [HttpPost]
        public async Task<IHttpActionResult> Print()
        {
            var formData = System.Text.ASCIIEncoding.ASCII.GetString(Request.Content.ReadAsByteArrayAsync().Result);
            var document = Newtonsoft.Json.JsonConvert.DeserializeObject<Quanto.Printer.PrinterService.PrintDocument>(formData);
            bool result = await Task<bool>.Run(() => Quanto.Printer.PrinterService.Instance.Print(document));
            return this.Ok(result);
        }

        [Route("Print")]
        [HttpPost]
        public async Task<IHttpActionResult> Print(Quanto.Printer.PrinterService.PrintDocument document)
        {
            bool result = await Task<bool>.Run(() => Quanto.Printer.PrinterService.Instance.Print(document));
            return this.Ok(result);
        }

        [Route("SendSMS")]
        [HttpPost]
        public async Task<IHttpActionResult> SendSMS(Quanto.SMS.SMS document)
        {
            bool result = await Task<bool>.Run(() => Quanto.SMS.SMSManager.Instance.Sent(document));
            return this.Ok(result);
        }

        [Route("KillSMS/{id}/{mobileno}")]
        [HttpGet]
        public async Task<IHttpActionResult> KillSMS(string id,string mobileno)
        {
            bool result = await Task<bool>.Run(() => Quanto.SMS.SMSManager.Instance.KillSMS(id,mobileno));
            return this.Ok(result);
        }

       
    }
}
