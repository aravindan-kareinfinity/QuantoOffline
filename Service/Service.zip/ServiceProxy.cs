﻿using Quanto;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Quanto
{
    public class ServiceProxy
    {
        private static ServiceProxy instance;
        public static ServiceProxy Instance
        {
            get
            {
                if (instance == null)
                    instance = new ServiceProxy();

                return instance;
            }
        }

        private ServiceProxy()
        {
            URI = System.Configuration.ConfigurationManager.AppSettings["ServerURL"] + "/CompanyService";
            SMSURI = System.Configuration.ConfigurationManager.AppSettings["ServerURL"] + "/SmsmessageService";
        }

        string URI = "http://localhost:1706/CompanyService";
        string SMSURI = "http://localhost:1706/SmsmessageService";
        public async Task<bool> AddPrinter(PrinterConfig creteria)
        {
            using (var client = new HttpClient())
            {
                var serializedProduct = JsonConvert.SerializeObject(creteria);
                var content = new StringContent(serializedProduct, Encoding.UTF8, "application/json");

                Logger.Current.Info("Adding Printer to " + URI + "/AddPrinter");
                Logger.Current.Info(content.ToJSON());

                var result = Task.Run(() => client.PostAsync(URI + "/AddPrinter", content)).Result;
                if (result.IsSuccessStatusCode)
                {
                    string json = await result.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<bool>(json);
                }
            }
            return false;
        }


        public async Task<LicenseInfo> CreateClientLicense(PrinterConfig creteria)
        {
            using (var client = new HttpClient())
            {
                var serializedProduct = JsonConvert.SerializeObject(creteria);
                var content = new StringContent(serializedProduct, Encoding.UTF8, "application/json");

                Logger.Current.Info("CreateClientLicense " + URI + "/CreateClientLicense");
                Logger.Current.Info(content.ToJSON());

                var result = Task.Run(() => client.PostAsync(URI + "/CreateClientLicense", content)).Result;
                if (result.IsSuccessStatusCode)
                {
                    string json = await result.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<LicenseInfo>(json);
                }
            }
            return null;
        }

        public async Task<bool> SendPasscode(PrinterConfig creteria)
        {
            using (var client = new HttpClient())
            {
                var serializedProduct = JsonConvert.SerializeObject(creteria);
                var content = new StringContent(serializedProduct, Encoding.UTF8, "application/json");

                Logger.Current.Info("Adding Printer to " + URI + "/SendPasscode");
                Logger.Current.Info(content.ToJSON());

                var result = Task.Run(() => client.PostAsync(URI + "/SendPasscode", content)).Result;
                if (result.IsSuccessStatusCode)
                {
                    string json = await result.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<bool>(json);
                }
            }
            return false;
        }

        public async Task<bool> TriggerSchedule(DateTime dt)
        {
            using (var client = new HttpClient())
            {
                var result = Task.Run(() => client.GetAsync(SMSURI + "/StartScheduleMessage")).Result;
                if (result.IsSuccessStatusCode)
                {
                    string json = await result.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<bool>(json);
                }
            }
            return false;
        }
        public async Task<bool> UpdateStatus(SMS.SMS creteria)
        {
            using (var client = new HttpClient())
            {
                var serializedProduct = JsonConvert.SerializeObject(creteria);
                var content = new StringContent(serializedProduct, Encoding.UTF8, "application/json");

                var result = Task.Run(() => client.PostAsync(SMSURI + "/UpdateStatus", content)).Result;
                if (result.IsSuccessStatusCode)
                {
                    string json = await result.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<bool>(json);
                }
            }
            return false;
        }
    }
}
