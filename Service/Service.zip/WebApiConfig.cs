﻿using Microsoft.Owin.Extensions;
using Microsoft.Owin.FileSystems;
using Microsoft.Owin.Hosting;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;


[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace Quanto
{
    public class OwinCofiguration
    {
        public void Configuration(IAppBuilder appBuilder)
        {
            appBuilder.Use((context, next) =>
            {
                var req = context.Request;
                context.Response.Headers.Remove("Server");
                return next.Invoke();
            });
            appBuilder.UseStageMarker(PipelineStage.PostAcquireState);

            HttpConfiguration config = new HttpConfiguration();
            config.MapHttpAttributeRoutes();
            config.Formatters.JsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/html"));
            appBuilder.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);
            appBuilder.UseWebApi(config);
            if (System.Diagnostics.Debugger.IsAttached)
            {
                var path = new System.IO.FileInfo(System.Reflection.Assembly.GetExecutingAssembly().FullName).Directory.FullName;
                var fileSystem = new VirtualFileSystem(path);
                var random = new Random(int.MaxValue);
                appBuilder.UseStaticFiles(new Microsoft.Owin.StaticFiles.StaticFileOptions()
                {
                    FileSystem = fileSystem,
                    OnPrepareResponse = ctx =>
                    {
                        ctx.OwinContext.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
                        ctx.OwinContext.Response.Headers["Pragma"] = "no-cache";
                        ctx.OwinContext.Response.Headers["Expires"] = "0";
                    }
                });
                appBuilder.UseStageMarker(PipelineStage.MapHandler);
            }
        }
    }


    public class VirtualFileSystem : Microsoft.Owin.FileSystems.IFileSystem
    {
        Microsoft.Owin.FileSystems.PhysicalFileSystem pfs;
        public VirtualFileSystem(string path)
        {
            pfs = new Microsoft.Owin.FileSystems.PhysicalFileSystem(path);
        }

        public bool TryGetDirectoryContents(string subpath, out IEnumerable<IFileInfo> contents)
        {
            var result = pfs.TryGetDirectoryContents(subpath, out contents);
            return result;
        }

        public bool TryGetFileInfo(string subpath, out IFileInfo fileInfo)
        {
            var result = pfs.TryGetFileInfo(subpath, out fileInfo);
            return result;
        }
    }


    
}
