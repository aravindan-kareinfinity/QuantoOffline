﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Quanto
{
    public partial class Configform : Form
    {
        public Configform()
        {
            InitializeComponent();
        }

        private void btnstart_Click(object sender, EventArgs e)
        {
            AddOrUpdateAppSettings("CompanyCode", textBox1.Text);
            AddOrUpdateAppSettings("ServerURL", textBox2.Text);
            AddOrUpdateAppSettings("LocationCode", textBox3.Text);
            AddOrUpdateAppSettings("PrintOn80Port", checkBox1.Checked ? "true":"false");
            this.DialogResult = DialogResult.OK;
        }

        public static void AddOrUpdateAppSettings(string key, string value)
        {
            try
            {
                var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                var settings = configFile.AppSettings.Settings;
                if (settings[key] == null)
                {
                    settings.Add(key, value);
                }
                else
                {
                    settings[key].Value = value;
                }
                configFile.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
            }
            catch (ConfigurationErrorsException)
            {
                Console.WriteLine("Error writing app settings");
            }
        }

        private void Configform_Load(object sender, EventArgs e)
        {
            textBox1.Text = System.Configuration.ConfigurationManager.AppSettings["Companycode"];
            textBox2.Text = System.Configuration.ConfigurationManager.AppSettings["ServerURL"];
            textBox2.Text = System.Configuration.ConfigurationManager.AppSettings["LocationCode"];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var result = ServiceProxy.Instance.SendPasscode(new PrinterConfig()
            {
                employeecode = txtemployeecode.Text
            });
            if (result.Result)
            {
                MessageBox.Show("Send to Mobile");
            }
            else
            {
                MessageBox.Show("Login to Quanto and get the passcode");
            }
        }

        private void CreateLicenseFile(string content)
        {
            string file = System.Reflection.Assembly.GetExecutingAssembly().Location+".license";
            System.IO.File.WriteAllText(file, content);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var cert = new PrinterConfig();
            cert.companycode = textBox1.Text;
            cert.server = textBox2.Text;
            cert.locationcode = textBox3.Text;
            cert.employeecode = txtemployeecode.Text;
            cert.passcode = txtpasscode.Text;
            cert.licensekey = Quanto.WinService.License.Key;
            cert.computername = Dns.GetHostName();
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    cert.ipaddress = ip.ToString();
                    break;
                }
            }
            var result = ServiceProxy.Instance.CreateClientLicense(cert);
            if(result == null || result.Result == null)
            {
                MessageBox.Show("Can't connect ther server, check the internet/intranet");
                return;
            }
            if(!result.Result.passcode)
            {
                MessageBox.Show("Passcode mismatch, please check the passcode");
                return;
            }
            if (result.Result.exist)
            {
                MessageBox.Show("License already exist.");
                CreateLicenseFile(result.Result.publickey);
                return;
            }
            if (!result.Result.created)
            {
                MessageBox.Show("License created successfully.");
                CreateLicenseFile(result.Result.publickey);
                return;
            }
        }
    }
}


